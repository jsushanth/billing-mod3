
C:\>sqlplus trg728/training728@//10.219.34.3:1521/orcl

SQL*Plus: Release 11.2.0.2.0 Production on Wed Dec 19 09:47:50 2018

Copyright (c) 1982, 2014, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Release 11.2.0.1.0 - Production

SQL> CREATE TABLE product(product_code NUMBER PRIMARY KEY,product_name VARCHAR2(20),product_category VARCHAR2(20),product_description VARCHAR2(30),product_price NUMBER);

Table created.

SQL> CREATE TABLE sales(sales_id NUMBER,product_code NUMBER REFERENCES product(product_code),quantity NUMBER,sales_date DATE,line_total NUMBER);

Table created.

SQL> CREATE sequence productCode_sequence start with 1000;

Sequence created.


SQL>  select productCode_sequence.nextval from dual;

   NEXTVAL
----------
      1000

SQL> commit;

Commit complete.

SQL>
