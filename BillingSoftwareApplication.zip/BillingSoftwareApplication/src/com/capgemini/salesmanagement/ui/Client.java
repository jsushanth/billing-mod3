package com.capgemini.salesmanagement.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.ecxeption.ProductException;
import com.capgemini.salesmanagement.service.IProductService;
import com.capgemini.salesmanagement.service.ProductService;
import com.cg.librarian.service.LibrarianServiceImpl;





public class Client {
	static Scanner scan=new Scanner(System.in);
	static IProductService productService=null;
	static ProductService productServiceImpl=null;
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) throws ProductException {
		PropertyConfigurator.configure("resources/log4j.properties");
		ProductBean productBean=null;
		Object productCode=null;
		int option=0;
		while(true){
			
		System.out.println("Billing Software Application");
		System.out.println("--------------------------------");
		System.out.println("1.Enter Product Details");
		System.out.println("2. Calculate Total and displaying the bill");
		System.out.println("3.Exit");
		System.out.println("Select your choice");
		try {
			
			switch (option) {
			case 1:
				
				
				while(productBean==null){
					productBean=populateProductBean();
					
				}
				try {
					productService=new ProductService();
					productCode=productService.insertSalesDetails(productBean);
					System.out.println("product details has been successfully added");
					System.out.println("book id is"+productCode );
				}
				finally{
					productCode=null;
					productService=null;
					productBean=null;
					
				}
				break;
				
				
				
			case 2:
				try {
					productService=new ProductServiceImpl();
					System.out.println("Enter product code:");
					System.out.println(productService.searchproductDetails(scan.next()));
					
				} catch (Exception e) {
					e.printStackTrace();
					// TODO: handle exception
				}
				break;
			

			default:
				break;
			}
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
	private static ProductBean populateProductBean() {
		// TODO Auto-generated method stub
		ProductBean productBean=new ProductBean();
		System.out.println("\n Enter the Product details");
		System.out.println("Enter the product code");
		productBean.setProductCode(scan.nextInt());
		System.out.println("Enter the product quantity:");
		productBean.setQuantity(scan.nextInt());
		
		
		productServiceImpl=new ProductService();
		try {
			productServiceImpl.validateProduct(productBean);
			return productBean;
		} catch (ProductException productException) {
			System.out.println("invalid data");
			System.out.println(productException.getMessage()+"\n try again");
			System.exit(0);
			// TODO: handle exception
		}
		return null;
	}
	}
