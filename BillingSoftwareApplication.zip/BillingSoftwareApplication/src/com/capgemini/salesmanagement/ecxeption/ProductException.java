package com.capgemini.salesmanagement.ecxeption;

public class ProductException extends Exception{
	public ProductException(String obj){
		System.out.println(obj);
}
}