package com.capgemini.salesmanagement.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.dao.IProductDAO;
import com.capgemini.salesmanagement.ecxeption.ProductException;


class ProductDAOTest {
	 static IProductDAO dao;
     static ProductBean product;
     
     void testinsertSalesDetails() throws ProductException, ClassNotFoundException, IOException, SQLException {
 		assertNotNull(dao.insertSalesDetails(product));
 		//fail("Not yet implemented");
}
}