package com.capgemini.salesmanagement.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.capgemini.salesmanagement.ecxeption.ProductException;
import com.capgemini.salesmanagement.service.ProductService;
import com.cg.librarian.dao.ILibrarianDAOImpl;
import com.cg.librarian.exception.LibrarianException;
import com.cg.librarian.util.DBConnection;

class DBConnectionTest {
	static ProductService daotest;
	static Connection dbCon;

	@BeforeClass
	public static void initialise() {
		daotest = new ProductService ();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	
	@Test
	public void test() throws ProductException, ClassNotFoundException, IOException, SQLException {
		Connection dbCon = DBconnection.getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daotest = null;
		dbCon = null;
	}

	
}
