package com.capgemini.salesmanagement.bean;

public class ProductBean {
	private int productCode;
	private String productName;
	private String productCategory;
	private String productDescription;
	private float productPrice;
	private int Quantity;
	private float lineTotal;
	
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		this.Quantity = quantity;
	}
	public float getLineTotal() {
		return lineTotal;
	}
	public void setLineTotal(float lineTotal) {
		this.lineTotal = lineTotal;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append("Printing Billing Software Application Details \n");
		sb.append("Product  Id: " +productCode +"\n");
		sb.append("Product Name: "+ productName +"\n");
		sb.append("product Category: "+ productCategory +"\n");
		sb.append("product Description: "+ productDescription +"\n");
		sb.append("Product Price: "+ productPrice +"\n");
		sb.append("Quantity: "+ Quantity +"\n");
		sb.append("Line Total: "+ lineTotal +"\n");
		return sb.toString();
	}
	
	
}
