package com.capgemini.salesmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.dao.IProductDAO;
import com.capgemini.salesmanagement.dao.ProductDAO;
import com.capgemini.salesmanagement.ecxeption.ProductException;



public class ProductService implements IProductService{
IProductDAO productdao=new ProductDAO();



	@Override
	public ProductBean getProductDetails(int productCode) {
		// TODO Auto-generated method stub
		int b=productCode;
		ProductBean a=productdao.getProductDetails(productCode);
		return a;
		
	}

	@Override
	public boolean insertSalesDetails(ProductBean product) {
		// TODO Auto-generated method stub
		boolean productSeq;
		productSeq=productdao.insertSalesDetails(product);
		return productSeq; 
	
	}
	
	
	
	public void validateProduct(ProductBean bean) throws ProductException{
		List<String> validationErrors=new ArrayList<String>();
		
		
		if(!(isValidProductName(bean.getProductName())))
		{
			validationErrors.add("\n Product name should be in alphabets and start with capital, should have minimum 3 characerts:");
		}
		
		if(!(isValidProductCategory(bean.getProductCategory()))) {
			validationErrors.add("\n Product category  should have alphabets and start with capital,  have minimum 3  characters");
		}
		
		if(!(isValidProductDescription(bean.getProductDescription()))) {
			validationErrors.add("\n  Product description  should have alphabets and start with capital, have minimum 3  characters ");
		}
		if(!(isValidProductPrice(bean.getProductPrice()))) {
			validationErrors.add("\n product price  should be positive number");
		}
		if(!(isValidQuantity(bean.getQuantity()))) {
			validationErrors.add("\n quantityt should be mentioned in  positive number");
		}
		if(!(isValidLineTotal(bean.getLineTotal()))) {
			validationErrors.add("\n total  should be positive number");
		}
		if(!validationErrors.isEmpty()) {
			throw new ProductException(validationErrors +" ");
		}
	}

	private boolean isValidLineTotal(float lineTotal) {
		// TODO Auto-generated method stub
		return lineTotal>0;
	}

	private boolean isValidQuantity(int quantity) {
		// TODO Auto-generated method stub
		return quantity>=0;
	}

	private boolean isValidProductPrice(Object ProductPrice) {
		// TODO Auto-generated method stub
		return ProductPrice;
	}

	private boolean isValidProductDescription(String productDescription) {
		// TODO Auto-generated method stub
		Pattern descriptionPattern=Pattern.compile("^[A-Z][a-z]{3,}$");
		Matcher descriptionMatcher=descriptionPattern.matcher(productDescription);
		return descriptionMatcher.matches();
	}

	private boolean isValidProductCategory(String productCategory) {
		// TODO Auto-generated method stub
		Pattern categoryPattern=Pattern.compile("^[A-Z][a-z]{3,}$");
		Matcher categoryMatcher=categoryPattern.matcher( productCategory);
		return categoryMatcher.matches();
	}

	private boolean isValidProductName(String productName) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Z][a-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(productName);
		return nameMatcher.matches();
	}
	public boolean validateProductCode(CharSequence productCode) {
		Pattern codePattern=Pattern.compile("[0-9][1,4]");
		Matcher codeMatcher=codePattern.matcher(productCode);
		if(codeMatcher.matches())
			return true;
		else
		   return false;
	

}
}
