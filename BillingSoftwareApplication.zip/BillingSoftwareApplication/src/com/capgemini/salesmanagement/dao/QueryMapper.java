package com.capgemini.salesmanagement.dao;

public interface QueryMapper {
	public static final  String INSERT_SALES_DETAILS="insert into product values(productCode_sequence.nextval,?,?,?,?,?,?)";
	public static final  String Product_Code="select max(productcode) from product";
	public static final  String GET_PRODUCT_DETAILS="select * from product where prouctCode=?";
	
}
