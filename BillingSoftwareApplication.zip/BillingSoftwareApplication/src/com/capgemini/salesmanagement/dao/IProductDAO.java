package com.capgemini.salesmanagement.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.salesmanagement.bean.ProductBean;

public interface IProductDAO {
	public ProductBean getProductDetails(int productCode);
	public boolean insertSalesDetails(ProductBean product) throws ClassNotFoundException, IOException, SQLException;
	ProductBean getProductDetails(String productCode) throws ClassNotFoundException, IOException, SQLException;
	
}
