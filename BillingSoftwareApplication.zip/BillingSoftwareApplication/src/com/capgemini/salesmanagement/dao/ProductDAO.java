package com.capgemini.salesmanagement.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.ecxeption.ProductException;
import com.capgemini.salesmanagement.util.DBConnection;




public class ProductDAO implements IProductDAO{
static Logger logger=Logger.getLogger(ProductDAO.class);
public ProductDAO()
{
PropertyConfigurator.configure("resources/log4j.properties");

}
//------------------------ 1. Billing Software Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getProductDetails(ProductBean product)
	 - Input Parameters	:	ProductBean product
	 - Return Type		:	String
	 - Throws			:  	ProductException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	12/19/2018
	 - Description		:	Adding Product
	 ********************************************************************************************************/



	@Override
	public ProductBean getProductDetails(String productCode) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		logger.info("in getProductDetails method");
		Connection connection=DBConnection.getConnection();
		ProductBean bean=null;
		try {
			PreparedStatement preparedStatement=null;
			preparedStatement=connection.prepareStatement(QueryMapper.GET_PRODUCT_DETAILS);
				
			
			preparedStatement.setString(1,productCode);
			ResultSet rs=preparedStatement.executeQuery();
			bean=new ProductBean();
			while(rs.next()){
				bean.setProductCode(rs.getInt(1));
				bean.setProductName(rs.getString(2));
				bean.setProductCategory(rs.getString(3));
				bean.setProductDescription(rs.getString(4));
				bean.setProductPrice(rs.getFloat(5));
				bean.setQuantity(rs.getInt(6));
				bean.setLineTotal(rs.getFloat(7));
			}
			if(!rs.next()){
				logger.error("Search failed ");
				

			}
			else {
				logger.info("search successfully");
			}
		
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return bean;
		
	}
	//------------------------ 1. Billing Software Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	insertSalesDetails(String productCode)
		 - Input Parameters	:	ProductCode
		 - Return Type		:	ProductBean
		 - Throws			:  	ProductException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	12/19/2018
		 - Description		:	insert Sales details
		 * @throws SQLException 
		 * @throws IOException 
		 * @throws ClassNotFoundException 
		 ********************************************************************************************************/

	@Override
	public boolean insertSalesDetails(ProductBean product) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub

		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String productCode = null  ;
		int queryResult=0;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_SALES_DETAILS);
			
			preparedStatement.setString(1,product.getProductName());
			preparedStatement.setString(2, product.getProductCategory());
			preparedStatement.setString(3,product.getProductDescription());
			preparedStatement.setFloat(4, product.getProductPrice());
			preparedStatement.setInt(5, product.getQuantity());
			preparedStatement.setFloat(6, product.getLineTotal());
			queryResult=preparedStatement.executeUpdate();
			Statement st=connection.createStatement();
			resultSet=st.executeQuery(QueryMapper.Product_Code);
			
			
			if(resultSet.next()){
				productCode=resultSet.getString(1);
				logger.info("product details added successfully:");
				
				
				
			}
			if(queryResult==0){
				logger.error("Insertion failed ");
				throw new ProductException("Inserting product details failed ");

			}
			else {
				logger.info("added successfully");
			}
			
			} catch (Exception e) {
				e.printStackTrace();
				// TODO: handle exception
			}
			return productCode != null;
	}



	@Override
	public ProductBean getProductDetails(int productCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
